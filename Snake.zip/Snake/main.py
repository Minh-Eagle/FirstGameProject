import pygame
from random import randint
def play():
    pygame.init()

    frame_size_x, frame_size_y = 600, 480
    square_x, square_y = frame_size_x // 10, frame_size_y // 10
    screen = pygame.display.set_mode((frame_size_x, frame_size_y))
    pygame.display.set_caption('Snake')
    running = True
    GREEN = (0, 255, 0)
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    BLUE = (0, 0, 255)
    clock = pygame.time.Clock()

    # snake position
    #tail - head
    snakes = [[15, 24], [16,24], [17,24]]
    direction = 'right'
    change = direction

    apple = [randint(0,square_x-1), randint(0, square_y-1)]

    font_small = pygame.font.SysFont('Arial', 20)
    font_big = pygame.font.SysFont('Arial', 50)
    score = 0

    restart = False
    food_spawn = True

    snake_speed = 20

    while running:
        clock.tick(snake_speed)
        screen.fill(BLACK)

        tail_x = snakes[0][0]
        tail_y = snakes[0][1]

        # draw snake
        for snake in snakes:
            pygame.draw.rect (screen, GREEN, (snake[0] * 10, snake[1] * 10, 10, 10))

        # draw apple
        pygame.draw.rect(screen, RED, (apple[0] * 10, apple[1] * 10, 10, 10) )

        # point, spawn apple
        if snakes[-1][0] == apple[0] and snakes[-1][1] == apple[1]:
            snakes.insert(0, [tail_x, tail_y])
            food_spawn = False
            score += 1
        if not food_spawn:
            while True:
                # tạo 1 apple mới bất kì
                new_pos = [randint(0,square_x-1), randint(0,square_y-1)]
                # kiểm tra không được trùng với con rắn
                if new_pos not in snakes:
                    apple = new_pos
                    break # nếu không trùng thì dừng
            food_spawn = True

        # check crash with edge
        if snakes[-1][0] < 0 or snakes[-1][0] > square_x - 1 or snakes[-1][1] < 0 or snakes[-1][1] > square_y - 1:
            restart = True

        # check crash with body
        for i in range (len(snakes) - 1):
            if snakes[-1][0] == snakes[i][0] and snakes[-1][1] == snakes[i][1]:
                restart = True

        # Draw game over scene
        if restart == True:
            game_over = font_big.render('GAME OVER, score: ' + str(score), True, WHITE)
            play_again = font_big.render('Press Space to continue', True, WHITE)
            screen.blit(game_over, (50, 200))
            screen.blit(play_again, (50, 300))

        # snake move
        if restart == False:
            if change == 'right':
                direction = 'right'
                snakes.append([snakes[-1][0] + 1, snakes[-1][1]])
                snakes.pop(0)
            if change == 'left':
                direction = "left"
                snakes.append([snakes[-1][0] - 1, snakes[-1][1]])
                snakes.pop(0)
            if change == 'up':
                direction = "up"
                snakes.append([snakes[-1][0], snakes[-1][1] - 1])
                snakes.pop(0)
            if change == 'down':
                direction = "down"
                snakes.append([snakes[-1][0], snakes[-1][1] + 1])
                snakes.pop(0)

        # xử lý event
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and direction != 'down':
                    change = 'up'
                if event.key == pygame.K_DOWN and direction != 'up':
                    change = 'down'
                if event.key == pygame.K_LEFT and direction != 'right':
                    change = 'left'
                if event.key == pygame.K_RIGHT and direction != 'left':
                    change = 'right'
                if event.key == pygame.K_SPACE and restart == True:
                    restart = False
                    snakes = [[15, 24], [16,24], [17,24]]
                    apple = [randint(0,square_x-1), randint(0, square_y-1)]
                    score = 0
                    direction = 'right'
                    change = direction

        pygame.display.flip()

    pygame.display.quit()

if __name__ == "__main__":
    play()
