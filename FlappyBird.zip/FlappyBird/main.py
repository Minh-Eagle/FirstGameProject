import pygame
from random import randint
import math
import os
GAME_FOLDER = os.path.dirname(__file__)
ASSETS_FOLDER = os.path.join(GAME_FOLDER, 'assets')

# --- 1. KHAI BÁO HẰNG SỐ ---
WIDTH, SCREEN_HEIGHT = 400, 650
HEIGHT = 600
SKY_COLOR = (78, 192, 202)

TUBE_WIDTH = 75
TUBE_VELOCITY = 3
TUBE_GAP = 220
TUBE_DISTANCE = 280
cap_height = 25
cap_width = TUBE_WIDTH + 10
BIRD_X = 50
BIRD_WIDTH, BIRD_HEIGHT = 50, 35
GRAVITY = 0.45
BIRDFLAP = pygame.USEREVENT + 1

# --- 2. KHAI BÁO BIẾN TOÀN CỤC (GLOBAL) ---
screen = None
clock = None
tube1_x = tube2_x = tube3_x = 0
tube1_height = tube2_height = tube3_height = 0
bird_y = bird_drop_velocity = goc_xoay = 0
score = final_score = 0
high_score = 0
tube1_pass = tube2_pass = tube3_pass = False
touch = False
game_active = False
game_start = False
start_fade_counter = 0
end_fade_counter = 0
pop_up = 0
replay_rect = None

def draw_number_on_board(number, x_right, y, number_list):
    global screen
    number_str = str(number)
    for i in reversed(number_str):
        img = number_list[int(i)]
        img_width = img.get_width()
        x_right -= img_width
        screen.blit(img, (x_right, y))
        x_right -= 2

def update_high_score(x):
    current_score = x
    h_score = 0
    score_file = os.path.join(GAME_FOLDER, 'highscore.txt')
    try:
        with open(score_file, 'r') as f:
            content = f.read()
            if content: h_score = int(content)
    except:
        h_score = 0
    if current_score > h_score:
        h_score = current_score
        with open(score_file, 'w') as f:
            f.write(str(h_score))
    return h_score

def reset_game():
    global bird_y, bird_drop_velocity, TUBE_VELOCITY, score, touch, game_start
    global tube1_x, tube2_x, tube3_x, tube1_pass, tube2_pass, tube3_pass
    global end_fade_counter, start_fade_counter, goc_xoay, final_score, pop_up
    global tube1_height, tube2_height, tube3_height

    goc_xoay = 0
    start_fade_counter = 255
    end_fade_counter = 0
    pop_up = 100

    bird_y = 300
    bird_drop_velocity = 0
    TUBE_VELOCITY = 3
    score = 0
    final_score = 0
    touch = False
    game_start = False

    tube1_x = 600
    tube2_x = tube1_x + TUBE_DISTANCE
    tube3_x = tube2_x + TUBE_DISTANCE

    tube1_height = randint(0, 380)
    tube2_height = randint(0, 380)
    tube3_height = randint(0, 380)

    tube1_pass = tube2_pass = tube3_pass = False

def update_logic():
    global tube1_x, tube2_x, tube3_x, tube1_height, tube2_height, tube3_height
    global bird_y, bird_drop_velocity
    global score, tube1_pass, tube2_pass, tube3_pass, sand_x

    # Di chuyển ống
    tube1_x -= TUBE_VELOCITY
    tube2_x -= TUBE_VELOCITY
    tube3_x -= TUBE_VELOCITY

    # Vật lý rơi
    sand_y = HEIGHT - BIRD_HEIGHT + 6
    if bird_y < sand_y:
        bird_y += bird_drop_velocity
        bird_drop_velocity += GRAVITY
    else:
        bird_drop_velocity = 0
        bird_y = sand_y

    # Tạo ống mới
    if tube1_x < -TUBE_WIDTH:
        tube1_x = tube3_x + TUBE_DISTANCE
        tube1_height = randint(0, 380)
        tube1_pass = False
    if tube2_x < -TUBE_WIDTH:
        tube2_x = tube1_x + TUBE_DISTANCE
        tube2_height = randint(0, 380)
        tube2_pass = False
    if tube3_x < -TUBE_WIDTH:
        tube3_x = tube2_x + TUBE_DISTANCE
        tube3_height = randint(0, 380)
        tube3_pass = False

def collide():
    global touch, final_score, TUBE_VELOCITY, end_fade_counter, high_score, pop_up, replay_rect
    global tube1, tube2, tube3, tube1_inv, tube2_inv, tube3_inv, sand1, sand2, cap1, cap2, cap3, cap4, cap5, cap6

    # check collision
    sky = pygame.draw.line(screen, SKY_COLOR, (0, 0), (400, 0))
    collision_list = [tube1, tube2, tube3, tube1_inv, tube2_inv, tube3_inv, sand1, sand2, sky, cap1, cap2, cap3, cap4, cap5, cap6]
    for obj in collision_list:
        if bird.colliderect(obj):
            if not touch:
                sound_hit.play()
                if obj != sand1 and obj != sand2:
                    sound_die.play()
                touch = True
                final_score = score
            TUBE_VELOCITY = 0

    if touch:
        if end_fade_counter < 255: end_fade_counter += 5
        overlay_alpha = min(end_fade_counter, 120)
        overlay = pygame.Surface((WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(overlay_alpha)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))

        if pop_up > 0:
            pop_up -= 2
            if pop_up < 0: pop_up = 0

        high_score = update_high_score(final_score)

        # Vẽ bảng điểm (Tọa độ gốc của bạn)
        screen.blit(score_board_img, (WIDTH // 2 - 147.5, 90 + pop_up))

        # Vẽ số
        draw_number_on_board(final_score, 310, 90 + pop_up + 130, small_number_img)
        draw_number_on_board(high_score, 310, 90 + pop_up + 190, small_number_img)

        # Vẽ nút Replay
        replay_y = 90 + pop_up + 280
        screen.blit(replay_img, (WIDTH // 2 - 60, replay_y))
        replay_rect = pygame.Rect(WIDTH // 2 - 60, replay_y, 120, 65)

        # Vẽ Huy chương
        current_medal = None
        if final_score >= 40:
            current_medal = medal_platinum
        elif final_score >= 30:
            current_medal = medal_gold
        elif final_score >= 20:
            current_medal = medal_silver
        elif final_score >= 10:
            current_medal = medal_bronze

        if current_medal:
            screen.blit(current_medal, (WIDTH // 2 - 150 + 43, 233 + pop_up))

def draw_live_score(number_images):
    global screen
    score_str = str(score)
    total_width = sum(number_images[int(c)].get_width() for c in score_str)
    score_x = WIDTH // 2 - total_width // 2
    score_y = 20
    for c in score_str:
        img = number_images[int(c)]
        screen.blit(img, (score_x, score_y))
        score_x += img.get_width()

# --- 4. HÀM PLAY (HÀM CHÍNH) ---
def play():
    # --- PHẦN QUAN TRỌNG: KHAI BÁO GLOBAL ---
    global screen, clock, bird_image, rotated_bird, bird_frames, bird_index
    global background_image, night_image, sand_image, sand_x
    global top_tube_image, down_tube_image, tube_img
    global start_image, tap_img, score_board_img, replay_img
    global medal_bronze, medal_silver, medal_gold, medal_platinum
    global sound_wing, sound_hit, sound_point, sound_die
    global number_images, small_number_img
    global game_active, game_start, bird, sand1, sand2
    global tube1, tube2, tube3, tube1_inv, tube2_inv, tube3_inv, cap1, cap2, cap3, cap4, cap5, cap6
    global tube1_x, tube2_x, tube3_x, tube1_height, tube2_height, tube3_height
    global running
    global goc_xoay, bird_drop_velocity, score, tube1_pass, tube2_pass, tube3_pass, touch, bird_y

    pygame.init()
    pygame.mixer.init()
    screen = pygame.display.set_mode((WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption('Flappy Bird')
    clock = pygame.time.Clock()

    background_image = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'background.png')).convert_alpha()
    background_image = pygame.transform.scale(background_image, (400, 650))

    bird_down = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'bird_down.png')).convert_alpha()
    bird_mid = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'bird_mid.png')).convert_alpha()
    bird_up = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'bird_up.png')).convert_alpha()

    bird_down = pygame.transform.scale(bird_down, (BIRD_WIDTH, BIRD_HEIGHT))
    bird_mid = pygame.transform.scale(bird_mid, (BIRD_WIDTH, BIRD_HEIGHT))
    bird_up = pygame.transform.scale(bird_up, (BIRD_WIDTH, BIRD_HEIGHT))

    bird_frames = [bird_down, bird_mid, bird_up]
    bird_index = 0
    bird_image = bird_frames[bird_index]
    pygame.time.set_timer(BIRDFLAP, 200)

    sand_image = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'sand.png')).convert_alpha()
    sand_image = pygame.transform.scale(sand_image, (400, 50))
    sand_x = 0

    top_tube_image = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'pipe-down.png')).convert_alpha()
    down_tube_image = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'pipe-up.png')).convert_alpha()
    tube_img = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'pipe.png')).convert_alpha()

    start_image = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'start.png')).convert_alpha()
    start_image = pygame.transform.scale(start_image, (300, 500))

    tap_img = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'tap.png')).convert_alpha()
    tap_img = pygame.transform.scale(tap_img, (120, 80))

    score_board_img = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'scoreboard.png')).convert_alpha()
    score_board_img = pygame.transform.scale(score_board_img, (295, 350))

    replay_img = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'replay.png')).convert_alpha()
    replay_img = pygame.transform.scale(replay_img, (120, 65))

    medal_bronze = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'medal_bronze.png')).convert_alpha()
    medal_bronze = pygame.transform.scale(medal_bronze, (55, 55))

    medal_silver = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'medal_silver.png')).convert_alpha()
    medal_silver = pygame.transform.scale(medal_silver, (55, 55))

    medal_gold = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'medal_gold.png')).convert_alpha()
    medal_gold = pygame.transform.scale(medal_gold, (55, 55))

    medal_platinum = pygame.image.load(os.path.join(ASSETS_FOLDER, 'GameObject', 'medal_platinum.png')).convert_alpha()
    medal_platinum = pygame.transform.scale(medal_platinum, (55, 55))

    # --- LOAD ÂM THANH ---
    sound_wing = pygame.mixer.Sound(os.path.join(ASSETS_FOLDER, 'Sound', 'wing.wav'))
    sound_hit = pygame.mixer.Sound(os.path.join(ASSETS_FOLDER, 'Sound', 'hit.wav'))
    sound_point = pygame.mixer.Sound(os.path.join(ASSETS_FOLDER, 'Sound', 'point.wav'))
    sound_die = pygame.mixer.Sound(os.path.join(ASSETS_FOLDER, 'Sound', 'die.wav'))

    number_images = []
    for i in range(10):
        path = os.path.join(ASSETS_FOLDER, 'Numbers', str(i) + '.png')
        n = pygame.image.load(path).convert_alpha()
        n = pygame.transform.scale(n, (40, 50))
        number_images.append(n)

    small_number_img = []
    for i in range(10):
        path = os.path.join(ASSETS_FOLDER, 'SmallNumbers', str(i) + '.png')
        n = pygame.image.load(path).convert_alpha()
        n = pygame.transform.scale(n, (16, 28))
        small_number_img.append(n)

    game_active = False
    reset_game()

    running = True
    while running:
        clock.tick(60)
        screen.blit(background_image, (0, 0))

        sand_x -= TUBE_VELOCITY
        if sand_x <= -WIDTH: sand_x = 0

        if not game_active:
            screen.blit(sand_image, (sand_x, 600))
            screen.blit(sand_image, (sand_x + WIDTH, 600))

            # Start Screen
            screen.blit(start_image, (50, 50))

            for event in pygame.event.get():
                if event.type == pygame.QUIT: running = False
                if event.type == pygame.MOUSEBUTTONDOWN or (
                        event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE):
                    game_active = True
                    game_start = False
                    reset_game()
        else:
            # Vẽ ống
            tube1_img = pygame.transform.scale(tube_img, (TUBE_WIDTH, tube1_height))
            tube1 = screen.blit(tube1_img, (tube1_x, 0))
            tube2_img = pygame.transform.scale(tube_img, (TUBE_WIDTH, tube2_height))
            tube2 = screen.blit(tube2_img, (tube2_x, 0))
            tube3_img = pygame.transform.scale(tube_img, (TUBE_WIDTH, tube3_height))
            tube3 = screen.blit(tube3_img, (tube3_x, 0))

            top_tube_surf = pygame.transform.scale(top_tube_image, (cap_width, cap_height))
            cap1 = screen.blit(top_tube_surf, (tube1_x - 5, tube1_height))
            cap2 = screen.blit(top_tube_surf, (tube2_x - 5, tube2_height))
            cap3 = screen.blit(top_tube_surf, (tube3_x - 5, tube3_height))

            tube1_inv_img = pygame.transform.scale(tube_img, (TUBE_WIDTH, HEIGHT - tube1_height - TUBE_GAP))
            tube1_inv = screen.blit(tube1_inv_img, (tube1_x, tube1_height + TUBE_GAP))
            tube2_inv_img = pygame.transform.scale(tube_img, (TUBE_WIDTH, HEIGHT - tube2_height - TUBE_GAP))
            tube2_inv = screen.blit(tube2_inv_img, (tube2_x, tube2_height + TUBE_GAP))
            tube3_inv_img = pygame.transform.scale(tube_img, (TUBE_WIDTH, HEIGHT - tube3_height - TUBE_GAP))
            tube3_inv = screen.blit(tube3_inv_img, (tube3_x, tube3_height + TUBE_GAP))

            down_tube_surf = pygame.transform.scale(down_tube_image, (cap_width, cap_height))
            cap4 = screen.blit(down_tube_surf, (tube1_x - 5, tube1_height + TUBE_GAP - cap_height))
            cap5 = screen.blit(down_tube_surf, (tube2_x - 5, tube2_height + TUBE_GAP - cap_height))
            cap6 = screen.blit(down_tube_surf, (tube3_x - 5, tube3_height + TUBE_GAP - cap_height))

            # Vẽ đất
            sand1 = screen.blit(sand_image, (sand_x, 600))
            sand2 = screen.blit(sand_image, (sand_x + WIDTH, 600))

            # Vẽ chim
            if touch:
                if goc_xoay > -90: goc_xoay -= 5
                if goc_xoay < -90: goc_xoay = -90

            bird_image = bird_frames[bird_index]
            rotated_bird = pygame.transform.rotate(bird_image, goc_xoay)
            new_rect = rotated_bird.get_rect(center=(BIRD_X + BIRD_WIDTH // 2, bird_y + BIRD_HEIGHT // 2))
            bird = screen.blit(rotated_bird, new_rect)

            # Logic
            if game_start:
                if bird_drop_velocity < 0:
                    goc_xoay = 25
                elif bird_drop_velocity > 0:
                    goc_xoay -= 3
                    if goc_xoay < -90: goc_xoay = -90

                update_logic()
                draw_live_score(number_images)

                if tube1_x + TUBE_WIDTH <= BIRD_X and not tube1_pass:
                    score += 1
                    tube1_pass = True
                    sound_point.play()
                if tube2_x + TUBE_WIDTH <= BIRD_X and not tube2_pass:
                    score += 1
                    tube2_pass = True
                    sound_point.play()
                if tube3_x + TUBE_WIDTH <= BIRD_X and not tube3_pass:
                    score += 1
                    tube3_pass = True
                    sound_point.play()
                collide()
            else:
                goc_xoay = 0
                bird_y = 300 + math.sin(pygame.time.get_ticks() * 0.005) * 10
                screen.blit(tap_img, (25, 350))

                if touch: collide()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == BIRDFLAP:
                    if bird_index < 2:
                        bird_index += 1
                    else:
                        bird_index = 0
                    bird_image = bird_frames[bird_index]
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if not game_start and not touch:
                        game_start = True
                        bird_drop_velocity -= 7
                        sound_wing.play()
                    elif game_start and not touch:
                        bird_drop_velocity = -7
                        sound_wing.play()
                    elif touch:
                        replay_rect = replay_img.get_rect(center=(WIDTH // 2, 400))
                        if replay_rect and replay_rect.collidepoint(event.pos):
                            reset_game()
                            sound_wing.play()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    if not game_start and not touch:
                        game_start = True
                        bird_drop_velocity = -7
                        sound_wing.play()
                    elif touch:
                        reset_game()
                    else:
                        bird_drop_velocity = 0
                        bird_drop_velocity -= 7
                        sound_wing.play()

        pygame.display.flip()
    pygame.display.quit()
if __name__ == "__main__":
    play()