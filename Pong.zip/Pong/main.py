import math
import pygame
import random
import os
GAME_FOLDER = os.path.dirname(__file__)
ASSETS_FOLDER = os.path.join(GAME_FOLDER, 'assets')
def play():
    pygame.init()

    WIDTH, HEIGHT = 500, 680
    play_width, play_height = 400, 650
    score_width, score_height = WIDTH - play_width, HEIGHT

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Pong")

    clock = pygame.time.Clock()

    # object size
    ball = pygame.Rect(play_width // 2 - 8, HEIGHT // 2 - 8, 16, 16)
    bot = pygame.Rect(play_width // 2 - 40, 30, 80, 15)
    player = pygame.Rect(play_width // 2 - 40, HEIGHT - 45, 80, 15)

    ball_speed = 6
    ball_speed_x, ball_speed_y = 0, 0
    player_speed, bot_speed = 6, 3.2

    ball_active = False
    ball_spawn_time = pygame.time.get_ticks()

    score_bot, score_player = 0, 0
    check_score = False
    direction = 0

    # Load ảnh số
    number_images = []
    try:
        for i in range(10):
            img_path = os.path.join(ASSETS_FOLDER, 'Numbers', str(i) + '.png')
            n = pygame.image.load(img_path)
            n = pygame.transform.scale(n, (40, 50))
            number_images.append(n)
    except Exception as e:
        print("lỗi ảnh")

    def draw_score(score_bot, score_player):
        score_str1 = str(score_bot)
        score_str2 = str(score_player)
        if len(number_images) > 0:
            for c in score_str1:
                img = number_images[int(c)]
                screen.blit(img, (WIDTH - score_width // 2 - 20, HEIGHT // 4 - 25))
            for d in score_str2:
                img = number_images[int(d)]
                screen.blit(img, (WIDTH - score_width // 2 - 20, HEIGHT * 0.75 - 25))

    running = True
    while running:
        clock.tick(60)
        screen.fill('black')
        pygame.draw.line(screen, 'white', (play_width, 0), (play_width, HEIGHT))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # --- LOGIC START BALL ---
        if not ball_active:
            if pygame.time.get_ticks() - ball_spawn_time >= 1000:
                ball_active = True
                angle = random.choice([45, 135, 225, 315])
                rad = math.radians(angle)
                ball_speed_x = math.cos(rad) * ball_speed
                ball_speed_y = math.sin(rad) * ball_speed

        # --- LOGIC MOVE BALL ---
        if ball_active:
            ball.x += ball_speed_x
            ball.y += ball_speed_y

            # Wall touch
            if ball.right >= play_width:
                ball.right = play_width
                ball_speed_x *= -1
            if ball.left <= 0:
                ball.left = 0
                ball_speed_x *= -1

            # 3. XỬ LÝ VA CHẠM VỢT (Góc nảy Arcade)
            # Kiểm tra va chạm: Player (bóng đi xuống) hoặc Bot (bóng đi lên)
            hit_player = ball.colliderect(player) and ball_speed_y > 0
            hit_bot = ball.colliderect(bot) and ball_speed_y < 0

            if hit_player or hit_bot:
                paddle = player if hit_player else bot

                # --- TÍNH TOÁN GÓC NẢY MỚI ---

                # B1. Tính độ lệch tâm (-1: mép trái, 0: giữa, 1: mép phải)
                offset = (ball.centerx - paddle.centerx) / (paddle.width / 2)

                # Clamp (kẹp) giá trị offset trong khoảng -1 đến 1 để tránh lỗi
                offset = max(-1, min(1, offset))

                # B2. Tính góc nảy dựa trên độ lệch
                # GÓC TỐI ĐA: 60 độ (con số này tạo cảm giác giống video nhất)
                MAX_BOUNCE_ANGLE = math.radians(60)

                bounce_angle = offset * MAX_BOUNCE_ANGLE

                # B3. Tính toán vận tốc mới

                ball_speed_x = ball_speed * math.sin(bounce_angle)

                # Xác định hướng Y (lên hay xuống)
                direction_y = -1 if hit_player else 1
                ball_speed_y = ball_speed * math.cos(bounce_angle) * direction_y

                # B4. Đẩy bóng ra khỏi vợt ngay lập tức (Chống kẹt)
                if hit_player:
                    ball.bottom = player.top - 1
                else:
                    ball.top = bot.bottom + 1

            # Score logic
            scored = False
            if ball.bottom < bot.top and not check_score:
                score_player += 1
                scored = True
            if ball.top > player.bottom and not check_score:
                score_bot += 1
                scored = True

            if scored:
                # Reset ball logic inlined
                ball.center = (play_width // 2, HEIGHT // 2)
                ball_speed_x, ball_speed_y = 0, 0
                ball_active = False
                check_score = False
                ball_spawn_time = pygame.time.get_ticks()

        # --- LOGIC PLAYER MOVE ---
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a] or keys[pygame.K_LEFT]: player.x -= player_speed
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]: player.x += player_speed
        if player.left <= 0: player.left = 0
        if player.right >= play_width: player.right = play_width

        # --- LOGIC BOT MOVE ---
        distance = ball.centerx - bot.centerx
        if abs(distance) <= bot_speed:
            bot.centerx = ball.centerx
        else:
            if distance > 0:
                bot.x += bot_speed
            else:
                bot.x -= bot_speed
        if bot.right >= play_width: bot.right = play_width
        if bot.left <= 0: bot.left = 0

        # --- DRAW OBJECTS ---
        pygame.draw.line(screen, 'white', (0, HEIGHT // 2), (play_width, HEIGHT // 2))
        pygame.draw.ellipse(screen, (255, 255, 100) if ball_active else (150, 150, 150), ball)
        pygame.draw.rect(screen, (0, 255, 255), player, border_radius=20)
        pygame.draw.rect(screen, (255, 50, 80), bot, border_radius=20)
        draw_score(score_bot, score_player)

        pygame.display.flip()

    pygame.display.quit()

if __name__ == "__main__":
    play()